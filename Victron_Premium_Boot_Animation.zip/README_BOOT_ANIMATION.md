# Premium Boot Animation - integratie

Bestand:
- `boot_animation.h`

## 1. Plaats het bestand
Zet `boot_animation.h` in dezelfde map als je `.ino`:
`ESP32RemoteForVictron_Touch_NL_Dashboard_V4/`

## 2. Include toevoegen
Bovenin je `.ino`, onder de andere includes:

```cpp
#include "boot_animation.h"
```

## 3. Aanroepen in setup()
Zoek in `setup()` het stuk waar:
- `sprite.createSprite(TFT_WIDTH, TFT_HEIGHT);`
- display orientation
- brightness / display init

klaar zijn.

Plaats daarna:

```cpp
RunPremiumBootAnimation();
displayDirty = true;
```

## 4. Optionele settings
Je kunt de settings uit `general_settings_boot_animation_additions.h` onderaan je `general_settings.h` zetten.

## Wat de animatie doet
- donkere premium AMOLED achtergrond
- glow-logo met gestileerde V + energieflits
- ronde progress-indicator
- bewegende datapunten rond het logo
- mini energie-flow: NET / ACCU / ZON
- status-pills: WiFi / MQTT / Touch
- nette progressbar
- afrondende settle-frame voordat het dashboard verschijnt

## Performance
De animatie gebruikt alleen vector drawing op de bestaande `TFT_eSprite`.
Geen grote bitmap arrays, geen externe assets, geen extra fontbestanden.

Aanbevolen:
- duration: 2200-3200 ms
- min frame: 24-32 ms
